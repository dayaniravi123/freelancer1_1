﻿using System;
class Program
{
    static void Main(string[] args)
    {
    }
}

public class Customer
{
    #region fields
    private int _id;
    private string _fName;
    private string _lName;
    #endregion

    #region properties
    public int id { get; set; }
    public string fName { get; set; }
    public string lName { get; set; }
    #endregion

    #region methods
    public string GetFullName()
    {
        return this._fName + " " + this._lName;
    }
    #endregion
}
