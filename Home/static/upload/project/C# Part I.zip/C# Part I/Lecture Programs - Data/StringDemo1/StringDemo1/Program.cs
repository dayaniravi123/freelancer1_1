﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            string s1 = "Hello ";
            string s2 = 2.ToString();
            string s3 = s2.Insert(1," World!");
            string s4 = string.Concat(s1, s3);
            Console.WriteLine(s4);

            string s5 = string.Copy(s4);
            if(s5.Equals(s4))
            {
                Console.WriteLine("S4: {0} S5:{1}  Equals!", s4, s5);
            }
            if((string.Equals(s1,s2)) == false)
            {
                Console.WriteLine("S1: {0} S2:{1}  Not equals!", s1, s2);
            }

            Console.WriteLine("Substring:{0}", s4.Substring(5));
            Console.WriteLine("Substring:{0}", s4.Substring(0,5));

            Console.ReadLine();

        }
    }
}
