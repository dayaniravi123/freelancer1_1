﻿using System;

namespace StructureDemo1
{
    public struct Item
    {
        public string name;
        public int code;
        public double price;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Item fan;
            fan.name = "Jadoo";
            fan.code = 32245;
            fan.price = 2349.99;

            Console.WriteLine("Name: {0}, Code: {1}, Price: {2}", fan.name, fan.code, fan.price);
        }
    }
}
