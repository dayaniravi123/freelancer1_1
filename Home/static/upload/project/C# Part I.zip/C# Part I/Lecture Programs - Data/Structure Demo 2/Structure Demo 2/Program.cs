﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure_Demo_2
{
    struct Rectangle
    {
        int a, b;
        public Rectangle(int x, int y)
        {
            a = x;
            b = y;
        }

        public int Area()
        {
            return a * b;
        }

        public void Display()
        {
            Console.WriteLine("Area: {0}", Area());
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect = new Rectangle(10, 20);
            rect.Display();
        }
    }
}
