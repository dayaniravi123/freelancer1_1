﻿using System;

namespace Array_Demo_Sorting
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 55, 40, 80, 65, 71 };

            Console.WriteLine("Given list: ");
            for(int i=0;i<numbers.Length;i++)
            {
                Console.WriteLine("Index:{0}, Value: {1}", i, numbers[i]);
            }
            Console.WriteLine();

            //Sorting begins

            for (int i = 0; i < numbers.Length; i++)
            {
                for (int j = i + 1; j < numbers.Length; j++)
                {
                    if (numbers[i] > numbers[j])
                    {
                        int temp = numbers[i];
                        numbers[i] = numbers[j];
                        numbers[j] = temp;
                    }
                }
            }
            Console.WriteLine("Sorted list: ");
            //Array.Sort(numbers);
            
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine("Index:{0}, Value: {1}", i, numbers[i]);
            }

            Console.WriteLine();
            Console.ReadLine();

        }
    }
}
