﻿using System;



class Program
{
    static void Main(string[] args)
    {
        int i = 0;
        int sumTotal,productTotal=0;
        int[] numbers = new int[3];
        numbers[0] = 101;
        numbers[1] = 102;
        numbers[2] = 102;
        PassByValue(i);
        Console.WriteLine("Pass by value: {0}",i);
        PassByReference(ref i);
        Console.WriteLine("Pass by reference: {0}", i);
        Calculate(10, 20,out sumTotal,out productTotal);
        Console.WriteLine("Out parameters:: {0}  {1}", sumTotal,productTotal);

        //ParamMethod();
        //ParamMethod(numbers);
        ParamMethod(1, 2, 3, 4, 5, 6);
        Console.ReadLine();
    }

    public static void PassByValue(int j)
    {
        j = 101;
    }

    public static void PassByReference(ref int j)
    {
        j = 101;
    }

    public static void Calculate(int fN,int sN, out int sum, out int product)
    {
        sum = fN + sN;
        product = fN * sN;
    }

    //public static void ParamMethod(params int[] Numbers, int i)
    public static void ParamMethod(params int[] Numbers)
    {
        Console.WriteLine("There are {0} elements", Numbers.Length);

        foreach(int i in Numbers)
        {
            Console.WriteLine(i);
        }
    }
}
