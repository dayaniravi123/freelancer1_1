﻿using System;
using System.Text;

namespace MutableStringDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder s = new StringBuilder();
            s.Append("C# is an");
            s.Append(" Object Oriented Language");
            Console.WriteLine(s);

            int n = s.Length;
            s.Insert(n, ". Ok.");
            Console.WriteLine(s);

            s.Remove(n-2,2);
            Console.WriteLine(s);

            Console.ReadLine();

        }
    }
}
